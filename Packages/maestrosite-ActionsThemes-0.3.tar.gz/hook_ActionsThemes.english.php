<?php

$txt['hook_ActionsThemes_override'] = 'Override Member\'s Theme';
$txt['hook_ActionsThemes_add'] = 'Add actions (coma separate)';
