<?php

//
//Settings on personal page
//
//Set subaction handler.
function hook_ActionsThemes_modify( &$subActions )
{
	//Set subaction handler
	$subActions['ActionsThemes'] = 'hook_ActionsThemes_modify_sa';

	//Add subaction to admin menu (modsettings area tabs)
	global $context;
	$context[$context['admin_menu_name']]['sections']['config']['areas']
		['modsettings']['subsections']['ActionsThemes'] = array('label' => 'ActionsThemes');
}
//subaction handler
function hook_ActionsThemes_modify_sa()
{
	global $context, $modSettings, $smcFunc, $scripturl;
	$context['post_url'] = $scripturl . '?action=admin;area=modsettings;sa=ActionsThemes';

	$default = array(1,1);

	if( isset($_POST['save']) and isset($_POST['at']) and is_array($_POST['at']) )
	{
		$list = array();
		if( isset($_POST['at']) and is_array($_POST['at']) )
			foreach( $_POST['at'] as $action => $th )
				if( !empty($th['id']) )
					$list[$action] = array( (int)$th['id'], !empty($th['override']) );

		if( isset($_POST['add']) )
		{
			$array = explode(',', $_POST['add'] );
			foreach( $array as $action )
			{
				$action = trim($action);
				if( $action and !isset($list[$action]) )
					$list[$action] = $default;
			}
		}
		//admin? no filter "actions"-names
		updateSettings(array( 'settings_updated' => time(), 'actionsthemes' => serialize($list) ));
		redirectexit( $context['post_url'] );
	}

	//Set current modsettings area tab:
	$context[$context['admin_menu_name']]['current_subsection'] = 'ActionsThemes';
	$context['sub_template'] = 'hook_ActionsThemes_modify_sa';
	$context['cat_bg_label'] = $context['title_bg_label'] = 'ActionsThemes';
	$context['template_layers'][] = 'cat_bg';
	$context['template_layers'][] = 'slice';

	//current themes
	$context['actionsthemes'] = false;
	if( !empty($modSettings['actionsthemes']) )
		$context['actionsthemes'] = unserialize($modSettings['actionsthemes']);

	if( empty($context['actionsthemes']) or !is_array($context['actionsthemes']) )
		$context['actionsthemes'] = array( 'admin' => $default, 'moderate' => $default );

	// Load up all the themes.
	$request = $smcFunc['db_query']('', 'SELECT id_theme, value
		FROM {db_prefix}themes
		WHERE variable = "name" AND id_member = 0
		ORDER BY id_theme'
	);
	$context['themes'] = array();
	while( $row = $smcFunc['db_fetch_assoc']($request) )
		$context['themes'][$row['id_theme']] = $row['value'];
	$smcFunc['db_free_result']($request);

	loadLanguage('hook_ActionsThemes');
}
//display settings personal page
function template_hook_ActionsThemes_modify_sa()
{
	global $context, $scripturl, $txt;

	echo '<div id="admincenter">
<form action="', $context['post_url'], '" method="post" accept-charset="', $context['character_set'], '">
	<dl class="settings">';

	foreach($context['actionsthemes'] as $action => $theme )
	{
		$a = htmlspecialchars($action);
		echo '<dt><a href="', $scripturl, '?action=', $a, '">action=', $a,
			'</a></dt><dd><select name="at[', $a, '][id]"><option value="0">---</option>';

		foreach( $context['themes'] as $id_theme => $th)
			echo '<option value="', (int)$id_theme, ($theme[0] == $id_theme) ? '" selected="selected" >' : '">',
				htmlspecialchars($th),'</option>';
		
		echo '</select> <input type="checkbox" name="at[', $a, '][override]" ',
			empty($theme[1]) ?  '/>' : 'checked="checked" />', $txt['hook_ActionsThemes_override'], '</dd>';
	}

	echo '<dt>', $txt['hook_ActionsThemes_add'], '</dt><dd><input name="add" value=""/></dd></dl>';

	template_button_submit();

	echo '</form>
</div>';
}


/**
 * Display controls (as themes decoration)
 *
 * @todo ? move to Generic?Controls?.template.php
 * @todo refact in class TemplateGeneric()
 */
/**
 * Catalog title
 */
function template_cat_bg( $label )
{
	echo '<div class="cat_bar"><h3 class="catbg">', $label, '</h3></div>';
}
/**
 * Simple title
 */
function template_title_bg( $label )
{
	echo '<div class="title_bar"><h3 class="titlebg">', $label, '</h3></div>';
}
/**
 * Button submit
 */
function template_button_submit( $label = null )
{
	global $txt;
	echo '<hr /><input type="submit" name="save" value="', $label ? $label : $txt['save'], '" class="button_submit floatright" /><br />';
}

/**
 * Slice division
 */
function template_slice_above()
{
	echo '<div class="windowbg2"><span class="topslice"><span></span></span><div class="content">';
}
function template_slice_below()
{
	echo '</div><span class="botslice"><span></span></span></div>';
}

/**
 * Roundframe division
 */
function template_roundframe_above()
{
	echo '<span class="upperframe"><span></span></span><div class="roundframe">';
}
function template_roundframe_below()
{
	echo '</div><span class="lowerframe"><span></span></span>';
}
/**
 * Catalog title layout
 */
function template_cat_bg_above()
{
	global $context;
	template_cat_bg( $context['cat_bg_label'] );
}
function template_cat_bg_below()
{
}

/**
 * Simple title layout
 */
function template_title_bg_above()
{
	global $context;
	template_title_bg( $context['title_bg_label'] );
}
function template_title_bg_below()
{
}

