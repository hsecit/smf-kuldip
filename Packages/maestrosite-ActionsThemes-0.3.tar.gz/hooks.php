<?php

return array(
	//
	// Admin only
	//
	'integrate_admin_include' => '$sourcedir/hook_ActionsThemes.php',//load integrations file

	// Personal subaction-page in ModSettings area (area=modsettings;sa=ActionsThemes)
	// ManageSettings.php:ModifyModSettings()
	// @hint load mod subaction page this
	'integrate_modify_modifications' => 'hook_ActionsThemes_modify',
);
