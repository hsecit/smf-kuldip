Изменение тем оформления в заданных разделах (action) - админка, справка, поиск, календарь и тд

Пример работы мода [url=http://smf2.maestrosite.ru/index.php?topic=35.0]http://smf2.MaestroSite.ru/index.php?topic=35.0[/url]
Сопровождение [url=http://maestrosite.ru/]http://MaestroSite.ru/[/url]
E-mail [email]smf@maestrosite.ru[/email]

Этот мод доступен по [url=http://creativecommons.org/licenses/by-sa/3.0/]лицензии Creative Commons Attribution-ShareAlike (Атрибуция — С сохранением условий) 3.0 Непортированная[/url].
