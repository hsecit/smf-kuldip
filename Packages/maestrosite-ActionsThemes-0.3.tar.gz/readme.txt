Allow change themes for selected actions - admin, help, search, calendar, etc.

Demo [url=http://smf2.maestrosite.ru/index.php?topic=35.0]http://smf2.MaestroSite.ru/index.php?topic=35.0[/url]
Support [url=http://maestrosite.ru/]http://MaestroSite.ru/[/url]
E-mail [email]smf@maestrosite.ru[/email]

This work is licensed under a [url=http://creativecommons.org/licenses/by-sa/3.0/]Creative Commons Attribution-ShareAlike 3.0 Unported License[/url].