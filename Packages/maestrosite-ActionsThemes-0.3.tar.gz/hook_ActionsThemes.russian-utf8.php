<?php

$txt['hook_ActionsThemes_override'] = 'Заменять тему оформления пользователя';
$txt['hook_ActionsThemes_add'] = 'Добавить разделы (через запятую)';

