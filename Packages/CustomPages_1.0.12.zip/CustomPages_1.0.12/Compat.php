<?php

/*
 
 Compat.php

 SMF 2.0 RC1, bug with table updating workaround by Robbo (robert@eninja.com.au)

 NOTE: I have only tested in SMF 2.0 RC1 with MySQL.
 
*/

// I am assuming every version of SMF 2.0 under RC1 is incompatible. Any that are compatible will be added to the following array.
global $forum_version, $db_type;

// Add versions that this bug is fixed in here
$compat = array('SMF 2.0 RC2'); 

if(!in_array($forum_version, $compat))
{
    // Fix the mysql function?
    if($db_type == 'mysql')
        $smcFunc['db_create_table'] = 'mysql_db_create_table';
        
    // Otherwise the postgresql function?
    elseif($db_type == 'postgresql')
        $smcFunc['db_create_table'] = 'post_db_create_table';
}

// Functions we overide with...

// Create a table.
//!!! Add/remove indexes too?
function mysql_db_create_table($table_name, $columns, $indexes = array(), $parameters = array(), $if_exists = 'update', $error = 'fatal')
{
	global $reservedTables, $smcFunc, $db_package_log, $db_prefix;

	// Strip out the table name, we might not need it in some cases
	$real_prefix = preg_match('~^(`?)(.+?)\\1\\.(.*?)$~', $db_prefix, $match) === 1 ? $match[3] : $db_prefix;

	// With or without the database name, the fullname looks like this.	
	$complete_table_name = empty($parameters['no_prefix']) ? $db_prefix . $table_name : $table_name;
	$full_table_name = empty($parameters['no_prefix']) ? $real_prefix . $table_name : $table_name;

	// First - no way do we touch SMF tables.
	if (in_array(strtolower($full_table_name), $reservedTables))
		return false;

	// Log that we'll want to remove this on uninstall.
	$db_package_log[] = array('remove_table', $full_table_name);

	// Slightly easier on MySQL than the others...
	$tables = $smcFunc['db_list_tables']();
	if (in_array($full_table_name, $tables))
	{
		// This is a sad day... drop the table?
		if ($if_exists == 'overwrite')
			$smcFunc['db_drop_table']($full_table_name, array('no_prefix' => true));
		elseif ($if_exists == 'ignore')
			return true;
		elseif ($if_exists == 'error')
			return false;
		// Otherwise we have to sort through the columns and add/remove ones which are wrong!
		else
		{
			$old_columns = $smcFunc['db_list_columns']($full_table_name, false, array('no_prefix' => true));
			foreach ($old_columns as $k => $v)
				$old_columns[$k] = strtolower($v);
			foreach ($columns as $column)
			{
				// Already exists?
				if (in_array(strtolower($column['name']), $old_columns))
				{
					$k = array_search(strtolower($column['name']), $old_columns);
					unset($old_columns[$k]);
				}
				// Doesn't - add it!
				else
					$smcFunc['db_add_column']($full_table_name, $column, array('no_prefix' => true));
			}
			// Whatever is left needs to be removed.
			if ($if_exists == 'update_remove')
			{
				foreach ($old_columns as $column)
					$smcFunc['db_remove_column']($full_table_name, $column, array('no_prefix' => true));
			}

			// All done!
			return true;
		}
	}

	// Righty - let's do the damn thing!
	$table_query = 'CREATE TABLE ' . $complete_table_name . "\n" .'(';
	foreach ($columns as $column)
	{
		// Auto increment is easy here!
		if (!empty($column['auto']))
		{
			$default = 'auto_increment';
		}
		elseif (isset($column['default']) && $column['default'] !== null)
			$default = 'default \'' . $column['default'] . '\'';
		else
			$default = '';

		// Sort out the size... and stuff...
		$column['size'] = isset($column['size']) && is_numeric($column['size']) ? $column['size'] : null;
		list ($type, $size) = $smcFunc['db_calculate_type']($column['type'], $column['size']);
		if ($size !== null)
			$type = $type . '(' . $size . ')';

		// Now just put it together!
		$table_query .= "\n\t`" .$column['name'] . '` ' . $type . ' ' . (!empty($column['null']) ? '' : 'NOT NULL') . ' ' . $default . ',';
	}

	// Loop through the indexes next...
	foreach ($indexes as $index)
	{
		$columns = implode(',', $index['columns']);

		// Is it the primary?
		if (isset($index['type']) && $index['type'] == 'primary')
			$table_query .= "\n\t" . 'PRIMARY KEY (' . implode(',', $index['columns']) . '),';
		else
		{
			if (empty($index['name']))
				$index['name'] = implode('_', $index['columns']);
			$table_query .= "\n\t" . (isset($index['type']) && $index['type'] == 'unique' ? 'UNIQUE' : 'KEY') . ' ' . $index['name'] . ' (' . $columns . '),';
		}
	}

	// No trailing commas!
	if (substr($table_query, -1) == ',')
		$table_query = substr($table_query, 0, -1);

	$table_query .= ') ENGINE=MyISAM';

	// Create the table!
	$smcFunc['db_query']('', $table_query,
		'security_override'
	);
}

// Create a table.
//!!! Add/remove indexes too?
function post_db_create_table($table_name, $columns, $indexes = array(), $parameters = array(), $if_exists = 'update', $error = 'fatal')
{
	global $reservedTables, $smcFunc, $db_package_log, $db_prefix;

	// Strip out the table name, we might not need it in some cases
	$real_prefix = preg_match('~^("?)(.+?)\\1\\.(.*?)$~', $db_prefix, $match) === 1 ? $match[3] : $db_prefix;

	// With or without the database name, the fullname looks like this.	
	$complete_table_name = empty($parameters['no_prefix']) ? $db_prefix . $table_name : $table_name;
	$full_table_name = empty($parameters['no_prefix']) ? $real_prefix . $table_name : $table_name;

	// First - no way do we touch SMF tables.
	if (in_array(strtolower($full_table_name), $reservedTables))
		return false;

	// Log that we'll want to remove this on uninstall.
	$db_package_log[] = array('remove_table', $full_table_name);

	// This... my friends... is a function in a half - let's start by checking if the table exists!
	$tables = $smcFunc['db_list_tables']();
	if (in_array($full_table_name, $tables))
	{
		// This is a sad day... drop the table?
		if ($if_exists == 'overwrite')
			$smcFunc['db_drop_table']($full_table_name, array('no_prefix' => true));
		elseif ($if_exists == 'ignore')
			return true;
		elseif ($if_exists == 'error')
			return false;
		// Otherwise we have to sort through the columns and add/remove ones which are wrong!
		else
		{
			$old_columns = $smcFunc['db_list_columns']($full_table_name, false, array('no_prefix' => true));
			foreach ($old_columns as $k => $v)
				$old_columns[$k] = strtolower($v);
			foreach ($columns as $column)
			{
				// Already exists?
				if (in_array(strtolower($column['name']), $old_columns))
				{
					$k = array_search(strtolower($column['name']), $old_columns);
					unset($old_columns[$k]);
				}
				// Doesn't - add it!
				else
					$smcFunc['db_add_column']($full_table_name, $column, array('no_prefix' => true));
			}
			// Whatever is left needs to be removed.
			if ($if_exists == 'update_remove')
			{
				foreach ($old_columns as $column)
					$smcFunc['db_remove_column']($full_table_name, $column, array('no_prefix' => true));
			}

			// All done!
			return true;
		}
	}

	// If we've got this far - good news - no table exists. We can build our own!
	$smcFunc['db_transaction']('begin');
	$table_query = 'CREATE TABLE ' . $complete_table_name . "\n" .'(';
	foreach ($columns as $column)
	{
		// If we have an auto increment do it!
		if (!empty($column['auto']))
		{
			$smcFunc['db_query']('', '
				CREATE SEQUENCE ' . $complete_table_name . '_seq',
				'security_override'
			);
			$default = 'default nextval(\'' . $complete_table_name . '_seq\')';
		}
		elseif (isset($column['default']) && $column['default'] !== null)
			$default = 'default \'' . $column['default'] . '\'';
		else
			$default = '';

		// Sort out the size...
		$column['size'] = isset($column['size']) && is_numeric($column['size']) ? $column['size'] : null;
		list ($type, $size) = $smcFunc['db_calculate_type']($column['type'], $column['size']);
		if ($size !== null)
			$type = $type . '(' . $size . ')';

		// Now just put it together!
		$table_query .= "\n\t\"" . $column['name'] . '" ' . $type . ' ' . (!empty($column['null']) ? '' : 'NOT NULL') . ' ' . $default;
	}

	// Loop through the indexes a sec...
	$index_queries = array();
	foreach ($indexes as $index)
	{
		$columns = implode(',', $index['columns']);

		// Primary goes in the table...
		if (isset($index['type']) && $index['type'] == 'primary')
			$table_query .= "\n\t" . 'PRIMARY KEY (' . implode(',', $index['columns']) . '),';
		else
		{
			if (empty($index['name']))
				$index['name'] = implode('_', $index['columns']);
			$index_queries[] = 'CREATE ' . (isset($index['type']) && $index['type'] == 'unique' ? 'UNIQUE' : '') . ' INDEX ' . $complete_table_name . '_' . $index['name'] . ' ON ' . $complete_table_name . ' (' . $columns . ')';
		}
	}

	// No trailing commas!
	if (substr($table_query, -1) == ',')
		$table_query = substr($table_query, 0, -1);

	$table_query .= ')';

	// Create the table!
	$smcFunc['db_query']('', $table_query,
		'security_override'
	);
	// And the indexes...
	foreach ($index_queries as $query)
		$smcFunc['db_query']('', $query,
		'security_override'
	);

	// Go, go power rangers!
	$smcFunc['db_transaction']('commit');
}

?>