<?php

/*******************************************************************************
	ATTENTION: If you are trying to install this manually, you should try
	the package manager. If that does not work, you can run this file by
	accessing it by url. Please ensure it is in the same location as your
	forum's SSI.php file.
*******************************************************************************/

//	eNinja - Custom Pages Version 1.0.12

//	If SSI.php is in the same place as this file, and SMF isn't defined, this is being run standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
{
	require_once(dirname(__FILE__) . '/SSI.php');
	$standalone = true;
}
//	Hmm... no SSI.php and no SMF?
elseif (!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s SSI.php.');

//	Make sure that we have the package database functions.
if(!array_key_exists('db_add_column', $smcFunc))
	db_extend('packages');

// Fix compatability issues
include('Compat.php');

// Columns for the custom pages table.
$columns = array(
    array(
        'name' => 'id_page',
        'type' => 'varchar',
        'size' => '255',
    ),
    array(
        'name' => 'page_title',
        'type' => 'varchar',
        'size' => '255',
    ),
    array(
        'name' => 'page_body',
        'type' => 'text',
    ),
    array(
        'name' => 'page_perms',
        'type' => 'varchar',
        'size' => '255',
    ),
    array(
        'name' => 'page_views',
        'type' => 'bigint',
        'size' => '11',
        'default' => '0',
    ),
    array(
        'name' => 'page_format',
        'type' => 'tinyint',
        'size' => '1',
        'default' => '0',
    ),
    array(
        'name' => 'page_time',
        'type' => 'int',
        'size' => '10',
        'default' => '0',
    ),
    array(
        'name' => 'page_settings',
        'type' => 'varchar',
        'size' => '10',
        'default' => '1:1:0',
    ),
    array(
        'name' => 'page_class',
        'type' => 'varchar',
        'size' => '255',
        'default' => 'tborder',
    ),
    array(
        'name' => 'page_styles',
        'type' => 'varchar',
        'size' => '255',
    ),
    array(
        'name' => 'title_class',
        'type' => 'varchar',
        'size' => '255',
        'default' => 'titlebg',
    ),
    array(
        'name' => 'title_styles',
        'type' => 'varchar',
        'size' => '255',
    ),
    array(
        'name' => 'body_class',
        'type' => 'varchar',
        'size' => '255',
        'default' => 'windowbg',
    ),
    array(
        'name' => 'body_styles',
        'type' => 'varchar',
        'size' => '255',
    ),
);

// Index for the custom pages table.
$indexes = array(
    array(
        'type' => 'primary',
        'columns' => array('id_page'),
    ),
);

// Create the custom pages table.
$smcFunc['db_create_table']('pages', $columns, $indexes);

// Columns for the log_cpfloodcontrol table
$columns = array(
    array(
        'name' => 'ip',
        'type' => 'char',
        'size' => '16',
    ),
    array(
        'name' => 'log_time',
        'type' => 'int',
        'size' => '10',
    ),
    array(
        'name' => 'id_page',
        'type' => 'varchar',
        'size' => '255',
    ),
);

// All are indexes
$indexes = array(
    array(
        'type' => 'primary',
        'columns' => array('ip', 'log_time', 'id_page'),
    ),
);

// And finally, create the table
$smcFunc['db_create_table']('log_cpfloodcontrol', $columns, $indexes);

// Here we need to make it compatable for uninstalls from either bugs in SMF 2.0 packaging or me being noob
$smcFunc['db_query']('', '
    DELETE FROM {db_prefix}log_packages
    WHERE package_id = {string:id} AND
        (version = {string:v1} OR
         version = {string:v2} OR
         version = {string:v3} OR
         version = {string:v4} OR
         version = {string:v5} OR
         version = {string:v6})',
    array(
        'id' => 'eNinja:CP',
        'v1' => '1.0.6',
        'v2' => '1.0.7',
        'v3' => '1.0.8',
        'v4' => '1.0.9',
        'v5' => '1.0.10',
        'v6' => '1.0.11', 
    )
);

//	Show a confirmation message, if an upgrade through SSI.php was successful.
if(SMF == 'SSI')
   echo 'Database Upgrade Complete!';
   
?>
