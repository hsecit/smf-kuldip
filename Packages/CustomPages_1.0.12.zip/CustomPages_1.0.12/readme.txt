This mod is used to create a custom page within your forum through the administration centre.

Basically you can add, edit or remove pages through the admin interface which makes use of the same BBCode editor you use when making a post. You also have the ability to add permissions to the pages so only certain users can view a particular page.

For any questions, suggestions or bug reports do not hesitate to post in the [url="http://www.simplemachines.org/community/index.php?topic=295943"]support thread[/url].